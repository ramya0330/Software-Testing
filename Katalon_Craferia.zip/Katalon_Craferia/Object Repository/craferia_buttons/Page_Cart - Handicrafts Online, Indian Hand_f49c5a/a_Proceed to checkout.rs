<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Proceed to checkout</name>
   <tag></tag>
   <elementGuidId>09ba2329-7687-4a58-8e3a-1ec3c40761b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.checkout-button.button.alt.wc-forward</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>059a5bfe-ab39-43fb-9be1-cc36d81d288c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/checkout/</value>
      <webElementGuid>ed2d6cc7-a2fb-4387-8773-c43edfc01210</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>checkout-button button alt wc-forward</value>
      <webElementGuid>64680669-0db4-4243-8cf1-df671bd4d7d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Proceed to checkout</value>
      <webElementGuid>0182a6ce-fb57-4052-8c21-0b17351411c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-7&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;cart-collaterals&quot;]/div[@class=&quot;cart_totals&quot;]/div[@class=&quot;wc-proceed-to-checkout&quot;]/a[@class=&quot;checkout-button button alt wc-forward&quot;]</value>
      <webElementGuid>9011959f-ef39-4a2c-9813-9d4b0db965f8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      <webElementGuid>6dabe75d-ce82-4111-b91b-b282ddc17214</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Proceed to checkout')]</value>
      <webElementGuid>ec95b290-0e02-4e88-8948-60eb368d27f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/checkout/')])[2]</value>
      <webElementGuid>b60173ec-bb07-4ffc-82a5-8b10dd94b30c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a</value>
      <webElementGuid>b2c352d6-c502-4424-8a77-472f413aa8e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/checkout/' and (text() = '
	Proceed to checkout' or . = '
	Proceed to checkout')]</value>
      <webElementGuid>d465afd8-c02b-470e-95f8-1d4cd50df3b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>

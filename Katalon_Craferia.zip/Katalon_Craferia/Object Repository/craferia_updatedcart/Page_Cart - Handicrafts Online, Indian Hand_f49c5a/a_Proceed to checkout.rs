<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Proceed to checkout</name>
   <tag></tag>
   <elementGuidId>5d871ff1-1115-4c2d-b1a8-bcbe0ba7f948</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.checkout-button.button.alt.wc-forward</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a42852d9-3323-4220-823a-605cf6664c4a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://craferia.com/checkout/</value>
      <webElementGuid>4a08f812-d8a8-47fc-a769-51c7cac4ef61</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>checkout-button button alt wc-forward</value>
      <webElementGuid>990777a3-3791-48ec-b0d5-de7c6370f97c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	Proceed to checkout</value>
      <webElementGuid>12a922d6-d4a9-4059-8f66-0c581be3ce3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-7&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;cart-collaterals&quot;]/div[@class=&quot;cart_totals&quot;]/div[@class=&quot;wc-proceed-to-checkout&quot;]/a[@class=&quot;checkout-button button alt wc-forward&quot;]</value>
      <webElementGuid>fe12111c-91f9-46a3-ac75-3804a7d128a0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-7']/div/div/div[2]/div/div/a</value>
      <webElementGuid>4e7fa4e8-790d-46f2-8e5f-7e1c895956fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Proceed to checkout')]</value>
      <webElementGuid>25c98c54-effa-41cb-ba3d-2112ba05084c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://craferia.com/checkout/')])[2]</value>
      <webElementGuid>17862cea-4e34-4e35-97f3-2ef29a70a46a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a</value>
      <webElementGuid>105c7fe5-2200-4620-9e51-9e0d8ab585d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://craferia.com/checkout/' and (text() = '
	Proceed to checkout' or . = '
	Proceed to checkout')]</value>
      <webElementGuid>0e29f48d-4263-42de-a513-097079e89479</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
